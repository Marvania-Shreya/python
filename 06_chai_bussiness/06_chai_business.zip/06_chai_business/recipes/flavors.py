def elachai_chai():
    return "Elachai chai is ready"

def ginger_chai():
    return "Ginger chai is ready"